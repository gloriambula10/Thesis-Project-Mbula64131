/*
 * two-bottleneck-tcp-eval.cc
 *
 * Thesis simulation script for:
 * Comparative Evaluation of Loss-Based, Delay-Based, and Model-Based TCP
 * Congestion Control Algorithms in NS-3
 *
 * Topology:
 *   S1..S12 -> R1 -> R2 -> R3 -> D1..D12
 *
 * Bottlenecks:
 *   R1--R2 = 50 Mbps
 *   R2--R3 = 20 Mbps
 *
 * Example run:
 *   ./ns3 run "scratch/two-bottleneck-tcp-eval --tcpType=TcpCubic --flows=3 --delayMs=50 --queuePkts=100 --run=1 --output=results/main.csv"
 *
 * Intended ns-3 version: 3.43
 */

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"

#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TwoBottleneckTcpEval");

static std::string
NormalizeTcpType(const std::string& tcpType)
{
    if (tcpType.rfind("ns3::", 0) == 0)
    {
        return tcpType;
    }
    return "ns3::" + tcpType;
}

static void
AppendCsvHeaderIfNeeded(const std::string& fileName)
{
    std::ifstream test(fileName.c_str());
    const bool exists = test.good();
    test.close();

    if (!exists)
    {
        std::ofstream out(fileName.c_str(), std::ios::out);
        out << "tcpType,flows,delayMs,queuePkts,run,flowId,sourceAddress,destinationAddress,"
            << "txPackets,rxPackets,lostPackets,txBytes,rxBytes,throughputMbps,"
            << "meanDelayMs,meanJitterMs,lossRatioPercent\n";
        out.close();
    }
}

static void
AppendScenarioSummaryHeaderIfNeeded(const std::string& fileName)
{
    std::ifstream test(fileName.c_str());
    const bool exists = test.good();
    test.close();

    if (!exists)
    {
        std::ofstream out(fileName.c_str(), std::ios::out);
        out << "tcpType,flows,delayMs,queuePkts,run,aggregateThroughputMbps,"
            << "averageThroughputMbps,averageDelayMs,averageJitterMs,"
            << "totalTxPackets,totalRxPackets,totalLostPackets,totalLossRatioPercent,"
            << "jainsFairnessIndex\n";
        out.close();
    }
}

int
main(int argc, char* argv[])
{
    std::string tcpType = "TcpCubic";
    uint32_t flows = 3;
    uint32_t maxFlows = 12;
    uint32_t delayMs = 50;
    uint32_t queuePkts = 100;
    uint32_t run = 1;
    double simTime = 120.0;
    uint32_t segmentSize = 1500;
    bool enablePcap = false;
    std::string output = "tcp-flow-results.csv";
    std::string summaryOutput = "tcp-scenario-summary.csv";
    std::string pcapPrefix = "two-bottleneck";

    CommandLine cmd(__FILE__);
    cmd.AddValue("tcpType", "TCP type: TcpNewReno, TcpCubic, TcpVegas, TcpBbr", tcpType);
    cmd.AddValue("flows", "Number of active TCP flows: 3, 6, or 12", flows);
    cmd.AddValue("delayMs", "Delay on each bottleneck link in milliseconds: 5, 50, or 100", delayMs);
    cmd.AddValue("queuePkts", "Queue size on point-to-point devices in packets: 50, 100, or 300", queuePkts);
    cmd.AddValue("run", "Run number for repeated simulations", run);
    cmd.AddValue("simTime", "Simulation duration in seconds", simTime);
    cmd.AddValue("segmentSize", "TCP segment size in bytes", segmentSize);
    cmd.AddValue("enablePcap", "Enable PCAP tracing for packet-level retransmission analysis", enablePcap);
    cmd.AddValue("output", "CSV file for per-flow results", output);
    cmd.AddValue("summaryOutput", "CSV file for scenario-level summary results", summaryOutput);
    cmd.AddValue("pcapPrefix", "Prefix for PCAP output files", pcapPrefix);
    cmd.Parse(argc, argv);

    if (flows == 0 || flows > maxFlows)
    {
        NS_FATAL_ERROR("Invalid flow count. Use 3, 6, or 12. Maximum supported value is " << maxFlows);
    }

    std::string tcpFullName = NormalizeTcpType(tcpType);
    TypeId tcpTid;
    if (!TypeId::LookupByNameFailSafe(tcpFullName, &tcpTid))
    {
        NS_FATAL_ERROR("Unknown TCP TypeId: " << tcpFullName
                                               << ". Expected examples: ns3::TcpNewReno, ns3::TcpCubic, ns3::TcpVegas, ns3::TcpBbr");
    }

    Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(tcpTid));
    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(segmentSize));
    Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(16 * 1024 * 1024));
    Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(16 * 1024 * 1024));

    RngSeedManager::SetSeed(1);
    RngSeedManager::SetRun(run);

    NodeContainer senders;
    senders.Create(maxFlows);

    NodeContainer receivers;
    receivers.Create(maxFlows);

    NodeContainer routers;
    routers.Create(3); // R1, R2, R3

    NodeContainer allNodes;
    allNodes.Add(senders);
    allNodes.Add(receivers);
    allNodes.Add(routers);

    InternetStackHelper internet;
    internet.Install(allNodes);

    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate", StringValue("100Mbps"));
    access.SetChannelAttribute("Delay", StringValue("2ms"));
    access.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePkts) + "p")));

    PointToPointHelper bottleneck1;
    bottleneck1.SetDeviceAttribute("DataRate", StringValue("50Mbps"));
    bottleneck1.SetChannelAttribute("Delay", StringValue(std::to_string(delayMs) + "ms"));
    bottleneck1.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePkts) + "p")));

    PointToPointHelper bottleneck2;
    bottleneck2.SetDeviceAttribute("DataRate", StringValue("20Mbps"));
    bottleneck2.SetChannelAttribute("Delay", StringValue(std::to_string(delayMs) + "ms"));
    bottleneck2.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", QueueSizeValue(QueueSize(std::to_string(queuePkts) + "p")));

    // Router-to-router links.
    NetDeviceContainer r1r2Devices = bottleneck1.Install(routers.Get(0), routers.Get(1));
    NetDeviceContainer r2r3Devices = bottleneck2.Install(routers.Get(1), routers.Get(2));

    Ipv4AddressHelper ipv4;

    ipv4.SetBase("10.100.1.0", "255.255.255.0");
    Ipv4InterfaceContainer r1r2Ifaces = ipv4.Assign(r1r2Devices);

    ipv4.SetBase("10.100.2.0", "255.255.255.0");
    Ipv4InterfaceContainer r2r3Ifaces = ipv4.Assign(r2r3Devices);

    // Sender access links and receiver access links.
    std::vector<Ipv4InterfaceContainer> senderIfaces;
    std::vector<Ipv4InterfaceContainer> receiverIfaces;
    senderIfaces.reserve(maxFlows);
    receiverIfaces.reserve(maxFlows);

    for (uint32_t i = 0; i < maxFlows; ++i)
    {
        NodeContainer senderLink(senders.Get(i), routers.Get(0));
        NetDeviceContainer senderDevices = access.Install(senderLink);

        std::ostringstream subnet;
        subnet << "10.1." << (i + 1) << ".0";
        ipv4.SetBase(subnet.str().c_str(), "255.255.255.0");
        senderIfaces.push_back(ipv4.Assign(senderDevices));

        NodeContainer receiverLink(routers.Get(2), receivers.Get(i));
        NetDeviceContainer receiverDevices = access.Install(receiverLink);

        std::ostringstream rSubnet;
        rSubnet << "10.2." << (i + 1) << ".0";
        ipv4.SetBase(rSubnet.str().c_str(), "255.255.255.0");
        receiverIfaces.push_back(ipv4.Assign(receiverDevices));
    }

    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    if (enablePcap)
    {
        access.EnablePcapAll(pcapPrefix + "-access", false);
        bottleneck1.EnablePcapAll(pcapPrefix + "-bottleneck1", false);
        bottleneck2.EnablePcapAll(pcapPrefix + "-bottleneck2", false);
    }

    uint16_t basePort = 5000;
    ApplicationContainer sourceApps;
    ApplicationContainer sinkApps;

    for (uint32_t i = 0; i < flows; ++i)
    {
        uint16_t port = basePort + i;

        Address sinkLocalAddress(InetSocketAddress(Ipv4Address::GetAny(), port));
        PacketSinkHelper sinkHelper("ns3::TcpSocketFactory", sinkLocalAddress);
        ApplicationContainer sinkApp = sinkHelper.Install(receivers.Get(i));
        sinkApp.Start(Seconds(0.0));
        sinkApp.Stop(Seconds(simTime + 1.0));
        sinkApps.Add(sinkApp);

        Ipv4Address receiverAddress = receiverIfaces[i].GetAddress(1); // Receiver-side interface.
        Address remoteAddress(InetSocketAddress(receiverAddress, port));
        BulkSendHelper sourceHelper("ns3::TcpSocketFactory", remoteAddress);
        sourceHelper.SetAttribute("MaxBytes", UintegerValue(0));
        sourceHelper.SetAttribute("SendSize", UintegerValue(segmentSize));

        ApplicationContainer sourceApp = sourceHelper.Install(senders.Get(i));
        // Small stagger reduces artificial synchronization while preserving the same scenario.
        double start = 1.0 + (0.02 * i);
        sourceApp.Start(Seconds(start));
        sourceApp.Stop(Seconds(simTime));
        sourceApps.Add(sourceApp);
    }

    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();

    Simulator::Stop(Seconds(simTime + 1.0));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    AppendCsvHeaderIfNeeded(output);
    AppendScenarioSummaryHeaderIfNeeded(summaryOutput);

    std::ofstream out(output.c_str(), std::ios::app);
    std::ofstream summary(summaryOutput.c_str(), std::ios::app);

    double aggregateThroughputMbps = 0.0;
    double sumThroughputMbps = 0.0;
    double sumThroughputSquared = 0.0;
    double sumDelayMs = 0.0;
    double sumJitterMs = 0.0;
    uint64_t totalTxPackets = 0;
    uint64_t totalRxPackets = 0;
    uint64_t totalLostPackets = 0;
    uint32_t countedDataFlows = 0;

    for (const auto& flow : stats)
    {
        Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(flow.first);

        // Keep only forward TCP data flows going to the PacketSink ports.
        if (t.protocol != 6 || t.destinationPort < basePort || t.destinationPort >= basePort + flows)
        {
            continue;
        }

        const FlowMonitor::FlowStats& st = flow.second;

        double duration = 0.0;
        if (st.rxPackets > 0)
        {
            duration = st.timeLastRxPacket.GetSeconds() - st.timeFirstRxPacket.GetSeconds();
        }
        if (duration <= 0.0)
        {
            duration = simTime - 1.0;
        }

        double throughputMbps = (st.rxBytes * 8.0) / duration / 1000000.0;
        double meanDelayMs = (st.rxPackets > 0) ? (st.delaySum.GetSeconds() / st.rxPackets * 1000.0) : 0.0;
        double meanJitterMs = (st.rxPackets > 1) ? (st.jitterSum.GetSeconds() / (st.rxPackets - 1) * 1000.0) : 0.0;
        double lossRatioPercent = ((st.rxPackets + st.lostPackets) > 0)
                                      ? (static_cast<double>(st.lostPackets) / (st.rxPackets + st.lostPackets) * 100.0)
                                      : 0.0;

        out << tcpType << "," << flows << "," << delayMs << "," << queuePkts << "," << run << ","
            << flow.first << "," << t.sourceAddress << "," << t.destinationAddress << ","
            << st.txPackets << "," << st.rxPackets << "," << st.lostPackets << ","
            << st.txBytes << "," << st.rxBytes << ","
            << std::fixed << std::setprecision(6) << throughputMbps << ","
            << meanDelayMs << "," << meanJitterMs << "," << lossRatioPercent << "\n";

        aggregateThroughputMbps += throughputMbps;
        sumThroughputMbps += throughputMbps;
        sumThroughputSquared += throughputMbps * throughputMbps;
        sumDelayMs += meanDelayMs;
        sumJitterMs += meanJitterMs;
        totalTxPackets += st.txPackets;
        totalRxPackets += st.rxPackets;
        totalLostPackets += st.lostPackets;
        countedDataFlows++;
    }

    double averageThroughputMbps = (countedDataFlows > 0) ? sumThroughputMbps / countedDataFlows : 0.0;
    double averageDelayMs = (countedDataFlows > 0) ? sumDelayMs / countedDataFlows : 0.0;
    double averageJitterMs = (countedDataFlows > 0) ? sumJitterMs / countedDataFlows : 0.0;
    double totalLossRatioPercent = ((totalRxPackets + totalLostPackets) > 0)
                                      ? (static_cast<double>(totalLostPackets) / (totalRxPackets + totalLostPackets) * 100.0)
                                      : 0.0;

    double jainFairness = 0.0;
    if (countedDataFlows > 0 && sumThroughputSquared > 0.0)
    {
        jainFairness = (sumThroughputMbps * sumThroughputMbps) /
                       (countedDataFlows * sumThroughputSquared);
    }

    summary << tcpType << "," << flows << "," << delayMs << "," << queuePkts << "," << run << ","
            << std::fixed << std::setprecision(6)
            << aggregateThroughputMbps << "," << averageThroughputMbps << ","
            << averageDelayMs << "," << averageJitterMs << ","
            << totalTxPackets << "," << totalRxPackets << "," << totalLostPackets << ","
            << totalLossRatioPercent << "," << jainFairness << "\n";

    out.close();
    summary.close();

    monitor->SerializeToXmlFile("flowmon-" + tcpType + "-f" + std::to_string(flows) +
                                    "-d" + std::to_string(delayMs) + "-q" + std::to_string(queuePkts) +
                                    "-r" + std::to_string(run) + ".xml",
                                true,
                                true);

    Simulator::Destroy();

    std::cout << "Completed scenario: "
              << "tcpType=" << tcpType
              << ", flows=" << flows
              << ", delayMs=" << delayMs
              << ", queuePkts=" << queuePkts
              << ", run=" << run
              << ", countedDataFlows=" << countedDataFlows
              << ", aggregateThroughputMbps=" << aggregateThroughputMbps
              << ", fairness=" << jainFairness
              << std::endl;

    return 0;
}
